package com.rover.mypets

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class PetDetailActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_PET_ID = "petId"
    }

    private val petStorage = PetStorage()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_detail)

        val petId: Int = intent.getIntExtra(EXTRA_PET_ID, 0)
        val pet = petStorage.getPet(petId)
        findViewById<TextView>(R.id.name).text = pet?.name
        findViewById<TextView>(R.id.breed).text = pet?.breed
        findViewById<TextView>(R.id.weight).text = getString(R.string.weight_kgs, pet?.weight)
    }

}
