package com.rover.mypets

import android.content.Context
import android.content.Intent
import android.util.AttributeSet
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PetView : LinearLayout {
    constructor(context: Context) : super(context, null)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defaultStyleAttr: Int) : super(
        context,
        attrs,
        defaultStyleAttr
    )

    private val nameView: TextView
    private val breedView:TextView
    private val weightView: TextView
    private val editButton: Button

    init {
        inflate(context, R.layout.view_pet, this)
        nameView = findViewById(R.id.name)
        breedView = findViewById(R.id.breed)
        weightView = findViewById(R.id.weight)
        editButton = findViewById(R.id.editButton)
    }

    fun setPet(pet: Pet) {
        nameView.text = pet.name
        breedView.text = pet.breed
        weightView.text = "${pet.weight} kgs"

        editButton.setOnClickListener {
            val intent = Intent(context, PetDetailActivity::class.java)
            intent.putExtra(PetDetailActivity.EXTRA_PET_ID, pet.id)
            context.startActivity(intent)
        }
    }

}