package com.rover.mypets

class PetStorage {
    private val petList = mutableListOf<Pet>(
        Pet(1, "Scooby", "Great Dane", 70),
        Pet(2, "Bluey", "Blue Heeler", 15),
        Pet(3, "Max", "Beagle", 10),
    )

//    fun getOwnerPets(ownerID: Int): List<Pet> {
//        return petList.filter { it.ownerID == ownerID }
//    }

    fun getPet(id: Int): Pet? {
        return petList.find { it.id == id }
    }
    fun getPets(): List<Pet> {
        return petList
    }

//    fun getPetsNumberPerOwner(ownerID: Int): Int {
//        return getOwnerPets(ownerID).size
//    }
}

data class Pet(
    var id: Int,
    var name: String,
    var breed: String,
    var weight: Int
)

data class Response (var pets: List<Pet>)