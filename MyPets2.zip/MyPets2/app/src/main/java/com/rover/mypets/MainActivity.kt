package com.rover.mypets

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    private val petStorage = PetStorage()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val petContainer = findViewById<LinearLayout>(R.id.pet_container)
        for (pet in petStorage.getPets()) {
            val petView = PetView(this)
            petView.setPet(pet)
            petContainer.addView(petView)
        }
    }
}