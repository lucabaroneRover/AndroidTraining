package com.rover.mypets

import android.os.Build
import android.os.Looper.getMainLooper
import android.widget.LinearLayout
import androidx.core.view.isVisible
import androidx.test.ext.junit.runners.AndroidJUnit4
import io.reactivex.Single
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import com.nhaarman.mockitokotlin2.whenever
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.MockitoAnnotations

@RunWith(AndroidJUnit4::class)
@Config(sdk = [Build.VERSION_CODES.P])
class MainActivityTests {

    private lateinit var activity: MainActivity
    private lateinit var petList: List<Pet>

    @Before
    fun setup() {
        activity = Robolectric.buildActivity(MainActivity::class.java).create().get()
        petList = listOf(
            Pet(1, "Test Name 1", "Test Breed 1", 50),
            Pet(2, "Test Name 2", "Test Breed 2", 50),
        )
    }

    @Test
    fun `test populatePetView works as expected`() {
        // Arrange
        val petContainer: LinearLayout = activity.findViewById(R.id.pet_container)

        // Act
        activity.populatePetView(petList)

        // Assert
        assertTrue(petContainer.isVisible)
        assertEquals(petContainer.childCount, 2)
    }

    @Test fun `getUserPets returns expected pets`() {
        val response = activity.getUserPets()
        assertEquals(PetStorage().getPets(), response.blockingGet().pets)
    }
}