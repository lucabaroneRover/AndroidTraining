package com.rover.mypets

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import com.google.gson.Gson
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.net.URL

class MainActivity : AppCompatActivity() {


    @SuppressLint("CheckResult")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getUserPets()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ result ->
                //success
                populatePetView(result.pets)
            }, { error ->
                Log.d("RxJava", "error: $error")
            })
    }

    fun getUserPets(): Single<Response> {
        return Single.create { emitter ->
            val petJson = URL("https://gist.githubusercontent.com/lucabaroneRover/2475624e8082aa2a98f89bc88a6b5418/raw/32fad99539c45758dbcb57d5f234d270690a7053/pets.json").readText()
            val pets = Gson().fromJson(petJson, Response::class.java)
            emitter.onSuccess(pets)
        }
    }

    fun populatePetView(pets: List<Pet>) {
        val petContainer: LinearLayout = findViewById(R.id.pet_container)

        for (pet in pets) {
            val petView = PetView(this)
            petView.setPet(pet)
            petContainer.addView(petView)
        }
    }
}
